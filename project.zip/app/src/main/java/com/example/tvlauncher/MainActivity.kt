package com.example.tvlauncher

import android.app.Activity
import android.content.Intent
import android.content.pm.ResolveInfo
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var grid: GridView
    private var apps = listOf<ResolveInfo>()
    private val prefs by lazy { getSharedPreferences("p", MODE_PRIVATE) }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        grid = GridView(this).apply {
            numColumns = 5
            horizontalSpacing = 24
            verticalSpacing = 24
            setPadding(48, 48, 48, 48)
            drawSelectorOnTop = true
            isFocusable = true
        }
        setContentView(grid)

        grid.setOnItemClickListener { _, _, i, _ ->
            packageManager.getLaunchIntentForPackage(apps[i].activityInfo.packageName)
                ?.let { startActivity(it) }
        }
        grid.setOnItemLongClickListener { _, _, i, _ ->
            val hidden = prefs.getStringSet("hidden", setOf())!!.toMutableSet()
            hidden.add(apps[i].activityInfo.packageName)
            prefs.edit().putStringSet("hidden", hidden).apply()
            load()
            true
        }
    }

    override fun onResume() {
        super.onResume()
        load()
        grid.requestFocus()
    }

    // Кнопка МЕНЮ на пульте возвращает все скрытые приложения
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            prefs.edit().remove("hidden").apply()
            Toast.makeText(this, "Скрытые приложения возвращены", Toast.LENGTH_SHORT).show()
            load()
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun load() {
        val hidden = prefs.getStringSet("hidden", setOf())!!
        fun q(cat: String) = packageManager.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(cat), 0
        )
        apps = (q(Intent.CATEGORY_LEANBACK_LAUNCHER) + q(Intent.CATEGORY_LAUNCHER))
            .distinctBy { it.activityInfo.packageName }
            .filter {
                it.activityInfo.packageName != packageName &&
                    it.activityInfo.packageName !in hidden
            }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }

        grid.adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(i: Int) = apps[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, v: View?, p: ViewGroup): View {
                val a = apps[i]
                return LinearLayout(this@MainActivity).apply {
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER
                    setPadding(16, 16, 16, 16)
                    addView(ImageView(context).apply {
                        setImageDrawable(a.loadIcon(packageManager))
                        layoutParams = LinearLayout.LayoutParams(128, 128)
                    })
                    addView(TextView(context).apply {
                        text = a.loadLabel(packageManager)
                        gravity = Gravity.CENTER
                        maxLines = 1
                        textSize = 16f
                    })
                }
            }
        }
    }
}
